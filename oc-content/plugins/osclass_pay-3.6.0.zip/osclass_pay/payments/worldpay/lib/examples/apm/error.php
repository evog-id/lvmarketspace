<?php
include('../header.php');
echo 'There was an error authorizing the APM Order ' . $_GET['orderCode'] . '<br/>';
